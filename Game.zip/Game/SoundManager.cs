using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static SoundManager Instance;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
    }

    // Call this method to create a sound event that monsters can hear
    public void CreateSound(Vector3 position)
    {
        Collider[] hitColliders = Physics.OverlapSphere(position, 10f); // Adjust the radius as needed

        foreach (var hitCollider in hitColliders)
        {
            MonsterController monster = hitCollider.GetComponent<MonsterController>();
            if (monster != null)
            {
                monster.HearSound(position); // Monster will move toward the sound
            }
        }
    }
}