using UnityEngine;

public class GameController : MonoBehaviour
{
    public GameObject player;
    public GameObject wall; // The wall preventing monsters from entering the safe zone
    public Transform safeZone;

    void Update()
    {
        // Check if the player enters the safe zone (escapes the monsters)
        if (Vector3.Distance(player.transform.position, safeZone.position) < 5f)
        {
            Debug.Log("Player has reached the safe zone! You've escaped!");
            // You can call a win condition here
            WinGame();
        }
    }

    void WinGame()
    {
        // Game won logic: You can display a win screen or restart the game
        Debug.Log("Player wins!");
        Time.timeScale = 0f; // Pause the game
    }
}