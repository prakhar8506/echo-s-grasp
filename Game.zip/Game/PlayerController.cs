using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float visionDistance = 10f;
    public LayerMask monsterLayer;

    private Vector3 targetPosition;
    private bool isInSight = false;

    void Update()
    {
        // Move the player
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 moveDirection = new Vector3(moveHorizontal, 0, moveVertical).normalized;

        transform.Translate(moveDirection * moveSpeed * Time.deltaTime);

        // Check if the player is within monster's vision
        CheckForMonsters();
    }

    void CheckForMonsters()
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position, transform.forward, out hit, visionDistance, monsterLayer))
        {
            MonsterController monster = hit.collider.GetComponent<MonsterController>();
            if (monster != null)
            {
                isInSight = true;
                Debug.Log("You saw a monster! Game Over.");
                // Call the GameOver function or any other logic for suicide here.
                GameOver();
            }
        }
        else
        {
            isInSight = false;
        }
    }

    void GameOver()
    {
        // This can be expanded to display UI, play animations, etc.
        Debug.Log("Player has committed suicide.");
        Time.timeScale = 0f; // Stop the game (pause).
    }
}