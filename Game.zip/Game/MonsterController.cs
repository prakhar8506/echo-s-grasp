using UnityEngine;

public class MonsterController : MonoBehaviour
{
    public float hearingRange = 15f;
    public float moveSpeed = 2f;
    private Transform player;
    private bool isMovingTowardsSound = false;
    private Vector3 soundPosition;

    void Start()
    {
        player = GameObject.FindWithTag("Player").transform;
    }

    void Update()
    {
        if (isMovingTowardsSound)
        {
            MoveTowardsSound();
        }
        else
        {
            // Patrol behavior or idle
        }
    }

    // This method will be called when the monster hears a sound.
    public void HearSound(Vector3 soundPosition)
    {
        this.soundPosition = soundPosition;
        isMovingTowardsSound = true;
    }

    void MoveTowardsSound()
    {
        Vector3 direction = (soundPosition - transform.position).normalized;
        transform.Translate(direction * moveSpeed * Time.deltaTime);

        // If the monster reaches the sound source, stop moving
        if (Vector3.Distance(transform.position, soundPosition) < 1f)
        {
            isMovingTowardsSound = false;
        }
    }
}